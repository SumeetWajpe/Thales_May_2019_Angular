import { Component, OnInit } from '@angular/core';
import { PostService } from './posts.service';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts-component.component.html',
  styleUrls: ['./posts-component.component.css'],
  providers:[PostService]
})
export default class PostsComponent implements OnInit {
allPosts:Post[] = [];
//   constructor(private postsServObj:PostService) { 
//  var observable = this.postsServObj.getPosts();
//  observable.subscribe(
//   (response)=>{
//     console.log(response);
//      this.allPosts = response;
//   }
// )
//}

constructor(private postsServObj:PostService){
            var aPromise = this.postsServObj.getPosts();
            aPromise.then(
              (response)=>this.allPosts = response,
              (err)=>console.log(err)
            );
}

  

  ngOnInit() {
  }

}


export const PI = 3.14;