import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  newProduct:Product= new Product();
  constructor() { }

  AddNewProduct(){
    // service to add a new product
  }

  ngOnInit() {
  }

}
