import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
    providedIn:'root'
})
export class AuthGaurd implements CanActivate {
    constructor(public authServObj:AuthService,public router:Router){

    }
        canActivate(currRoute:ActivatedRouteSnapshot,
            routerState:RouterStateSnapshot){
               // ?? condition -> true 
               if(!this.authServObj.getUserLoggedIn()){
                   this.router.navigate(["/"]);
               }
               return this.authServObj.getUserLoggedIn();
            }
}