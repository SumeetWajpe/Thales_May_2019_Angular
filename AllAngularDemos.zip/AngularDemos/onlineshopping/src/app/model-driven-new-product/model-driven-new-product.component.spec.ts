import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelDrivenNewProductComponent } from './model-driven-new-product.component';

describe('ModelDrivenNewProductComponent', () => {
  let component: ModelDrivenNewProductComponent;
  let fixture: ComponentFixture<ModelDrivenNewProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelDrivenNewProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelDrivenNewProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
