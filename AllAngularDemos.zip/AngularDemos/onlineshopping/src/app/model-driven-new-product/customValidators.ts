import {ValidatorFn, AbstractControl} from '@angular/forms';

export function restrictProductTitleValidator(productTitleReg:RegExp):ValidatorFn{
        return (control:AbstractControl):{[key:string]:any} | null=>{
            var restrictedTitleName =    productTitleReg.test(control.value)
            return restrictedTitleName ? {'restricedName':{value:control.value}} : null
        }
}