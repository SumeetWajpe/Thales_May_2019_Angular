import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';
import { ProductComponent } from './product/product.component';
import { OutOfStockPipe } from './product/outofstock.pipe';
//import  Posts from './posts-component/posts-component.component';
import { NewProductComponent } from './new-product/new-product.component';
import { ModelDrivenNewProductComponent } from './model-driven-new-product/model-driven-new-product.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGaurd } from './auth.gaurd';
import { LifeCycleHooksComponent } from './life-cycle-hooks/life-cycle-hooks.component';
import { MessageComponent } from './message/message.component';
import { PostsComponent } from './posts-component/posts-component.component';

// const routes:Routes = [
//   {path:'',component:ShoppingcartComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'newproduct',component:NewProductComponent},
//   {path:'postdetails/:id',component:PostDetailsComponent},
//   {path:'**',redirectTo:'/'}
// ];


const routes:Routes = [
  {path:'',component:LoginComponent},
  {path:'dashboard',component:DashboardComponent,
  children:[
    {path:'',component:ShoppingcartComponent},
    {path:'posts',component:PostsComponent},
    {path:'postdetails/:id',component:PostDetailsComponent},
    {path:'newproduct',component:NewProductComponent},
    {path:'lifecycle',component:LifeCycleHooksComponent}

  ],canActivate:[AuthGaurd]
}
];


@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartComponent,
    ProductComponent,
    OutOfStockPipe,  
    NewProductComponent,
    ModelDrivenNewProductComponent,
    PostDetailsComponent,
    LoginComponent,
    DashboardComponent,
    LifeCycleHooksComponent,
    MessageComponent,PostsComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    ReactiveFormsModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
