import { Component,Input} from '@angular/core';
import { Product } from '../product/product.model';
import { ProductsService } from '../products.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']

})
export class ProductComponent {
@Input() productdetails:Product = new Product();
isSelected:boolean=false;
isFree:boolean =false;
  
constructor(public servObj:ProductsService){

}
IncrementLikes(){
  this.productdetails.likes+=1;
}

}
