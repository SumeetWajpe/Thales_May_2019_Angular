import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostService } from '../posts-component/posts.service';
import { Post } from '../posts-component/post.model';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
thePostId:number;
thePost:Post;
  constructor(public currRoute:ActivatedRoute,public servObj:PostService) { }

  ngOnInit() {
    // read the params
    this.currRoute.params.subscribe(
      p => {
        this.thePostId = p.id;
        this.thePost = this.servObj.allPosts.find(post => post.id == this.thePostId)
      }
    )
  }

}
