import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isUserLoggedIn:boolean;
  constructor() {
    this.isUserLoggedIn = false;
   }
  getUserLoggedIn(){
    // ajax request !
        return this.isUserLoggedIn;
  }
  setUserLoggedIn(){
    this.isUserLoggedIn = true;
  }
}
