import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit,OnChanges {
  @Input() message:string="";
  constructor() { 
    console.log("Ctor : " + this.message);
  }
  ngOnChanges(){
    console.log("ngOnChanges : " + this.message);
  }

  ngOnInit() {
    console.log("ngOnInit : " + this.message);
  }

}
