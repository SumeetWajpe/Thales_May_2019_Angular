import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  txtUsername:string="";
  txtPassword:string=""
  constructor(public authServObj:AuthService,
    public router:Router) { }

  ngOnInit() {
  }

  AuthenticateUser(){
        if(this.txtUsername === "admin" && this.txtPassword === "admin"){
          this.authServObj.setUserLoggedIn();
          // redirect to /dashboard
          this.router.navigate(['/dashboard']);
        }
  }

}
