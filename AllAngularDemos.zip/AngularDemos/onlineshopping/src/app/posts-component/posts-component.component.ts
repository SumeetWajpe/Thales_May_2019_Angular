import { Component, OnInit } from '@angular/core';
import { PostService } from './posts.service';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts-component.component.html',
  styleUrls: ['./posts-component.component.css']
})
export class PostsComponent implements OnInit {
allPosts:Post[] = [];
//   constructor(public postsServObj:PostService) { 
//  var observable = this.postsServObj.getPosts();
//  observable.subscribe(
//   (response)=>{
//     console.log(response);
//      this.allPosts = response;
//   }
// )
//}

constructor(public postsServObj:PostService){
         
}

  

  ngOnInit() {

    if(this.postsServObj.allPosts.length == 0){
      var aPromise = this.postsServObj.getPosts();
      aPromise.then(
        (response)=>{
          this.allPosts = response;
          this.postsServObj.allPosts = response;
        }
          ,
        (err)=>console.log(err)
      );
    }

   
  }

}


export const PI = 3.14;