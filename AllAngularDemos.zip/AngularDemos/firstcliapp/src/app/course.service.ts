import { Course } from './course.model';

export class CourseService{
        allcourses:Course[] = [ {name:"React",duration:'3 Days'},
        {name:"Vue",duration:'2 Days'},
        {name:"Node",duration:'3 Days'}];

        getCourses():Course[]{
                return this.allcourses;
        }
    
}