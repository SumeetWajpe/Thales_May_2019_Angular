import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import {CourseComponent} from './course.component';
import { PlayerComponent } from './player/player.component';
import { PlayerService } from './player.service';

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    PlayerComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers:[PlayerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
