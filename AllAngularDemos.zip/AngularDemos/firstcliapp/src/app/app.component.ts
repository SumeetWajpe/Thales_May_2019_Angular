import { Component } from '@angular/core';
import { Course } from './course.model';
import { CourseService } from './course.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[CourseService]
})
export class AppComponent {

  imgUrl:string = "https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/300/full/angular2.png";
    courses:Course[] =[];// data from service !

    constructor(public servObj:CourseService){ // DI
        this.courses = this.servObj.getCourses(); // making use of service !
    }
}
