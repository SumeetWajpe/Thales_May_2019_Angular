import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../player.service';

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {
newPlayer:string="";
  constructor(public playerServObj:PlayerService) {
   }

   AddNewPlayer(){
     this.playerServObj.addNewPlayer(this.newPlayer);
   }

  ngOnInit() {
  }

}
