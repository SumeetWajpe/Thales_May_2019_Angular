import {Component, Input} from '@angular/core';

@Component({
    selector:'course',
    template:`<h1> {{coursedetails.name}} </h1>
    <h3>Duration : {{coursedetails.duration}}</h3>`
})
export class CourseComponent{
     @Input()   coursedetails:any={name:"Angular 7",duration:'5 Days'};
    

}