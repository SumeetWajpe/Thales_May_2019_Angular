export class PlayerService{
    allPlayers:string[] = ["Sachin","Virat","Lara"];

    getAllPlayers(){
            return this.allPlayers;
    }

    addNewPlayer(thePlayer:string){
        this.allPlayers.push(thePlayer);
    }
}