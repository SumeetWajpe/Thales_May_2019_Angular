var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var str = "Hello Typescript !"; // Type Inference
//str = 20;
console.log(str);
var x; // Type annotation !
x = 10;
var b = true;
var o;
var anyVar;
anyVar = 100;
anyVar = "Hello !";
anyVar = { name: 'Thales' };
anyVar = [10, 20, 30];
function Add(x, y) {
    if (x < 0) {
        return 'X Cannot be less than 0 !';
    }
    return x + y;
}
var result = Add(10, 20);
// Block scoped variables - let
if (true) {
    var blockScoped = 100;
    // let blockScoped = 100; // redeclaration not possible !
    if (true) {
        console.log(blockScoped);
    }
}
var PI = 3.14;
// const PI; // ERROR
// PI = 3.14; // ERROR
// PI= 3.1453; // ERROR
var cars = ["BMW", "FERRARI", "AUDI"];
var moreCars = ["TATA", "HYUNDAI"];
var allCars = cars.concat(moreCars); // Spread Operator !
//moreCars[0] = "HONDA"; // willnot change the value in allCars!
for (var _i = 0, allCars_1 = allCars; _i < allCars_1.length; _i++) {
    var c = allCars_1[_i];
    console.log(c);
}
// Spread Operator with objects
var person = { name: 'Sumeet', city: 'Pune' };
var trainer = __assign({}, person, { city: 'Mumbai', isMCT: true });
console.log(trainer.city);
// Functions
// function Square(x){
//     return x * x;
// }
//Square(); // Error !
// Optional Parameters
// function PrintBooks(author?:string,title?:string){
//      console.log(author,title);
// }
// PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way");
// Default Parameters
//     function PrintBooks(author:string="Unknown",title:string="Unknown"){
//         console.log(author,title);
//    }
//    PrintBooks();
//    PrintBooks(undefined,"Some Title");
//    PrintBooks("Sachin Tendulkar","Playing It My Way");
// Rest Parameters
// function PrintBooks(author:string,...titles:string[]){
//     console.log(author,titles);
// }
// PrintBooks("Sachin Tendulkar","Playing It My Way");
// PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");
// Function Declaration Syntax !
// function Square(x){
//     return x * x;
// }
// Function as an expression
// var Square = function(x){
//     return x * x;
// }
// Square(10);
// Arrow Functions
//    var Square = (x) => {
//        return x *x ;
//    }
// OR
var Square = function (x) { return x * x; };
// allCars.forEach(function(car){
//         console.log(car)
// })
// Using an arrow function !
allCars.forEach(function (car) { return console.log(car); });
var company = {
    name: 'Gemalto',
    giveSalary: function () {
        return 200000;
    }
};
// Class
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        // console.log('The Car ' + this.name + " is running at " + this.speed + " kmph !")
        return "The Car " + this.name + " is running at " + this.speed + " kmph !";
    };
    return Car;
}());
//    var c = new Car();
//    console.log(c.accelerate());
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, canFly) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = canFly;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true);
console.log(jbc.accelerate());
var CCompany = /** @class */ (function () {
    function CCompany() {
    }
    CCompany.prototype.giveSalary = function () {
        return 400000;
    };
    return CCompany;
}());
// Enhanced Class Syntax !
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var eCar = new EnhancedCar();
