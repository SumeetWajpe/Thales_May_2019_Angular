let a = 100;

var Arrow =() => console.log('Arrow');

function Addition(x:any,y:any){
    return x + y;
}