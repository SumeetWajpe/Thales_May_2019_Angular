var str = "Hello Typescript !"; // Type Inference
//str = 20;
console.log(str);

var x:number; // Type annotation !
x = 10;

var b:boolean = true;
var o:object;
var anyVar;
anyVar = 100;
anyVar = "Hello !";
anyVar = {name:'Thales'};
anyVar  = [10,20,30];

function Add(x:number,y:number):number|string{
   
    if(x<0){
        return 'X Cannot be less than 0 !';
    }
    return x + y;
}

var result:number|string = Add(10,20);


// Block scoped variables - let

            if(true){
                let blockScoped = 100;
                // let blockScoped = 100; // redeclaration not possible !
                if(true){
                    console.log(blockScoped);
                }
            }

            const PI = 3.14;

            // const PI; // ERROR
            // PI = 3.14; // ERROR
            // PI= 3.1453; // ERROR

            let cars:string[] = ["BMW","FERRARI","AUDI"];
            let moreCars:string[] = ["TATA","HYUNDAI"];
            let allCars:string[] = [...cars,...moreCars];// Spread Operator !

            //moreCars[0] = "HONDA"; // willnot change the value in allCars!
            for(let c of allCars){
                    console.log(c);
            }

            // Spread Operator with objects
            var person = {name:'Sumeet',city:'Pune'};
            var trainer = {...person,city:'Mumbai',isMCT:true};
            console.log(trainer.city);

            // Functions
            // function Square(x){
            //     return x * x;
            // }

            //Square(); // Error !

            // Optional Parameters
            // function PrintBooks(author?:string,title?:string){
            //      console.log(author,title);
            // }

            // PrintBooks();
            // PrintBooks("Sachin Tendulkar","Playing It My Way");

                // Default Parameters
            //     function PrintBooks(author:string="Unknown",title:string="Unknown"){
            //         console.log(author,title);
            //    }
   
            //    PrintBooks();
            //    PrintBooks(undefined,"Some Title");
            //    PrintBooks("Sachin Tendulkar","Playing It My Way");
   

                // Rest Parameters
                // function PrintBooks(author:string,...titles:string[]){
                //     console.log(author,titles);
                // }
                // PrintBooks("Sachin Tendulkar","Playing It My Way");
                // PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");

               
               // Function Declaration Syntax !
                // function Square(x){
                //     return x * x;
                // }

                // Function as an expression
                // var Square = function(x){
                //     return x * x;
                // }

                // Square(10);

                 // Arrow Functions
            //    var Square = (x) => {
            //        return x *x ;
            //    }

               // OR
                var Square = (x:number):number => x * x;

                // allCars.forEach(function(car){
                //         console.log(car)
                // })

            // Using an arrow function !
                allCars.forEach(car => console.log(car));


                // Object Oriented Features 

                // Interface

                interface ICompany{
                    name:string;
                    city?:string;
                    giveSalary():number;
                }
                var company:ICompany = {
                    name:'Gemalto',    
                    giveSalary:()=>
                     200000};

                     // Class

           class Car{
               name:string;
               speed:number;
                constructor(name:string="i20",speed:number=100){
                    this.name = name;
                    this.speed = speed;
                }

                accelerate(){
                    // console.log('The Car ' + this.name + " is running at " + this.speed + " kmph !")
                    return `The Car ${this.name} is running at ${this.speed} kmph !`
                }
           }

        //    var c = new Car();
        //    console.log(c.accelerate());

        class JamesBondCar extends Car{
                canFly:boolean;
                constructor(name:string,speed:number,canFly:boolean){
                    super(name,speed); // call base class ctor !
                    this.canFly = canFly;
                }
                accelerate(){
                    return super.accelerate() + " Can It Fly ? " + this.canFly;
                }
        }

        var jbc = new JamesBondCar("Aston Martin",500,true);
        console.log(jbc.accelerate());

        class CCompany implements ICompany{
            name:string;
            city?:string;
            giveSalary():number{
                return 400000;
            }
        }

        // Enhanced Class Syntax !

        class EnhancedCar{
            constructor(public name:string="i20",public speed:number=100){
                    
            }
        }

        var eCar = new EnhancedCar();
        