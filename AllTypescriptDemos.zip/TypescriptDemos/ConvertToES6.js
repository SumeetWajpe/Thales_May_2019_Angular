var a = 100;
var Arrow = function () { return console.log('Arrow'); };
function Addition(x, y) {
    return x + y;
}
