import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent  {

   heading:string="Online Shopping";
   companyName:string="";
   productName:string="";
  listOfProducts:Product[] = [];

  constructor(private serviceObj:ProductsService){
   
  }

  ngOnInit(){
    console.log(this.serviceObj.allProducts);
    if(this.serviceObj.allProducts.length == 0){
      var aPromise = this.serviceObj.getProducts();
      aPromise.then(
        (response)=>{
          this.listOfProducts = response;
          this.serviceObj.allProducts = response;
        },
        (err)=>{console.log(err)}
      )
    }
  }


}
