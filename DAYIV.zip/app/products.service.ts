import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './product/product.model';
@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  allProducts: Product[] = [];
  constructor(private httpServObj: HttpClient) { }
  
  getProducts() {
    return this.httpServObj.get<Product[]>('https://api.myjson.com/bins/ry3fs').toPromise();
  }

  deleteAProduct(theTitle:string){
      var theIndex = this.allProducts.findIndex(p=> p.title == theTitle)
      this.allProducts.splice(theIndex,1);
    }

    addANewProduct(aNewProduct:Product){
        this.allProducts.push(aNewProduct);
    }
}
