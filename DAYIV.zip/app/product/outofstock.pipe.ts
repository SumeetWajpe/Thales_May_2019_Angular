import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'outofstock'
})
export class OutOfStockPipe implements PipeTransform{
        transform(value:number,args:string){
            if(value === 0){
                return 'Out Of Stock !';
            }else{
                return value + " " + args;
            }
        }
}