import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Post } from './post.model';

@Injectable()
export class PostService{
    allPosts:Post[] = [];
    constructor(private httpServObj:HttpClient){  }
    // getPosts():Observable<Post[]>{
    //     // make an AJAX request !
    //     // HttpClient  -> Service given by Angular !
    //     // HttpClientModule  -> @angular/common/http
    //    return this.httpServObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts')
       
    // }

    getPosts(){
        return this.httpServObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts').toPromise();
    }
}