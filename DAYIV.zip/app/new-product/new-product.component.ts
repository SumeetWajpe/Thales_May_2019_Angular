import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  newProduct:Product= new Product();
  constructor(private servObj:ProductsService,
    private routerObj:Router) { }

  AddNewProduct(theForm){
    // service to add a new product
        if(theForm.valid){
          this.servObj.addANewProduct(this.newProduct);
          this.newProduct = new Product();
          theForm.reset();
          // redirect to /home
          this.routerObj.navigate(["/"]);
        }
  }

  ngOnInit() {
  }

}
