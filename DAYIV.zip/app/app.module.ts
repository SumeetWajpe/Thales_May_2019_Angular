import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';
import { ProductComponent } from './product/product.component';
import { OutOfStockPipe } from './product/outofstock.pipe';
import  Posts,{PI} from './posts-component/posts-component.component';
import { NewProductComponent } from './new-product/new-product.component';
import { ModelDrivenNewProductComponent } from './model-driven-new-product/model-driven-new-product.component';
import PostsComponent from './posts-component/posts-component.component';
import { PostDetailsComponent } from './post-details/post-details.component';

const routes:Routes = [
  {path:'',component:ShoppingcartComponent},
  {path:'posts',component:PostsComponent},
  {path:'newproduct',component:NewProductComponent},
  {path:'postdetails/:id',component:PostDetailsComponent}

  // {path:'electronics',children:[
  //   {path:'',component:ELECTRONICS}
  //   {path:'homeapplicances',component:HomeAPP}
  // ]}
];

@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartComponent,
    ProductComponent,
    OutOfStockPipe,
    Posts,
    NewProductComponent,
    ModelDrivenNewProductComponent,
    PostDetailsComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    ReactiveFormsModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
