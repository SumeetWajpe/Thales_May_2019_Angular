import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Product } from '../product/product.model';
import { ProductsService } from '../products.service';
import { restrictProductTitleValidator } from './customValidators';

@Component({
  selector: 'app-model-driven-new-product',
  templateUrl: './model-driven-new-product.component.html',
  styleUrls: ['./model-driven-new-product.component.css']
})
export class ModelDrivenNewProductComponent implements OnInit {

  productForm:FormGroup;
  newProduct:Product = new Product();

  constructor( private servObj:ProductsService) { }

  ngOnInit() {
      this.productForm = new FormGroup({
        'title':new FormControl(this.newProduct.title,[
          Validators.required,
          Validators.minLength(5),
          restrictProductTitleValidator(/laptop/i)
        ]),
        'price':new FormControl(this.newProduct.price),
        'rating':new FormControl(this.newProduct.rating),
        'ImageUrl':new FormControl(this.newProduct.ImageUrl),
        'likes':new FormControl(this.newProduct.likes),
        'quantity':new FormControl(this.newProduct.quantity)
      });// eof FormGroup
  }

  get f(){
    return this.productForm.controls;
  }

  AddNewProduct(){
   if(this.productForm.valid){
    this.servObj.addANewProduct(this.productForm.value);
    this.productForm.reset();
   }

  }

}
