import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-posts-component',
  templateUrl: './posts-component.component.html',
  styleUrls: ['./posts-component.component.css']
})
export default class PostsComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}


export const PI = 3.14;